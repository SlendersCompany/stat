<?php

namespace pocketmine\entity;


interface Attachable {

}