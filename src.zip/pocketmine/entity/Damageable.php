<?php

namespace pocketmine\entity;


interface Damageable {

}