<?php

namespace pocketmine\entity;


abstract class Hanging extends Entity implements Attachable {

}