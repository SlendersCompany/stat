<?php

namespace pocketmine\entity;


interface Tameable {

}