<?php

namespace pocketmine\block;

class GrayGlazedTerracotta extends GlazedTerracotta {
    
	protected $id = self::GRAY_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Gray Glazed Terracotta";
	}
	
}
