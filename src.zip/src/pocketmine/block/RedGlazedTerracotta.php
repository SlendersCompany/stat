<?php

namespace pocketmine\block;

class RedGlazedTerracotta extends GlazedTerracotta {
	
	protected $id = self::RED_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Red Glazed Terracotta";
	}
	
}
