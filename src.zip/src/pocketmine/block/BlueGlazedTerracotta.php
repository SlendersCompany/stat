<?php

namespace pocketmine\block;

class BlueGlazedTerracotta extends GlazedTerracotta {
	
	protected $id = self::BLUE_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Blue Glazed Terracotta";
	}
	
}
