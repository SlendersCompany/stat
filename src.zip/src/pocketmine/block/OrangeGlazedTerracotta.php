<?php

namespace pocketmine\block;

class OrangeGlazedTerracotta extends GlazedTerracotta {
	
	protected $id = self::ORANGE_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Orange Glazed Terracotta";
	}
	
}
