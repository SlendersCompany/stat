<?php

namespace pocketmine\block;

class LightBlueGlazedTerracotta extends GlazedTerracotta {
	
	protected $id = self::LIGHT_BLUE_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Light Blue Glazed Terracotta";
	}
	
}
