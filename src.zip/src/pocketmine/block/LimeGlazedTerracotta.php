<?php

namespace pocketmine\block;

class LimeGlazedTerracotta extends GlazedTerracotta {
	
	protected $id = self::LIME_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Lime Glazed Terracotta";
	}
	
}
