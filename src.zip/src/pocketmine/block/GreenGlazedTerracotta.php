<?php

namespace pocketmine\block;

class GreenGlazedTerracotta extends GlazedTerracotta {
	
	protected $id = self::GREEN_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Green Glazed Terracotta";
	}
	
}
