<?php

namespace pocketmine\block;

class BrownGlazedTerracotta extends GlazedTerracotta {
	
	protected $id = self::BROWN_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Brown Glazed Terracotta";
	}
	
}
