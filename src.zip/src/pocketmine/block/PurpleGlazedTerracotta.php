<?php

namespace pocketmine\block;

class PurpleGlazedTerracotta extends GlazedTerracotta {
    
	protected $id = self::PURPLE_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Purple Glazed Terracotta";
	}
	
}
