<?php

namespace pocketmine\block;

class LightGrayGlazedTerracotta extends GlazedTerracotta {
	
	protected $id = self::SILVER_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Light Gray Glazed Terracotta";
	}
	
}
