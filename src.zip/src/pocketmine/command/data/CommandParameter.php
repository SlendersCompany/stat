<?php

/**
 * GitHub: https://github.com/kezum1/
*/

declare(strict_types=1);

namespace pocketmine\command\data;

class CommandParameter{
	public const ARG_TYPE_STRING = 'string';
	public const ARG_TYPE_TARGET = 'target';
	public const ARG_TYPE_PLAYER = 'target';
	public const ARG_TYPE_BLOCK_POS = 'blockpos';
	public const ARG_TYPE_RAW_TEXT = 'rawtext';
	public const ARG_TYPE_INT = 'int';
	public const ARG_TYPE_STRING_ENUM = 'stringenum';

	private $name;
	private $type;
	private $optional;
	protected $enum_values = [];
	protected $overload;

	public function __construct(string $name, string $type, bool $optional = false, string $overload = 'default'){
		$this->name = $name;
		$this->type = $type;
		$this->optional = $optional;
		$this->overload = $overload;
	}

	final public function getName() : string{
		return $this->name;
	}

	final public function getType() : string{
		return $this->type;
	}

	final public function isOptional() : bool{
		return $this->optional;
	}

	final public function getEnumValues() : array{
		return $this->enum_values;
	}

	final public function getOverload() : string{
	    return $this->overload;
    }
}
